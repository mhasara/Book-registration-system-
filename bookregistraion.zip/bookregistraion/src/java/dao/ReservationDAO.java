
package dao;



import model.Reservation;
import java.sql.*;

public class ReservationDAO {
    public boolean reserveBook(Reservation reservation) {
        String sql = "INSERT INTO reservations (student_name, student_id, book_id) VALUES (?, ?, ?)";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, reservation.getStudentName());
            stmt.setString(2, reservation.getStudentId());
            stmt.setInt(3, reservation.getBookId());
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}
