package controller;

import dao.BookDAO;
import dao.ReservationDAO;
import model.Reservation;
import java.io.IOException;
import java.sql.SQLException;
import java.time.LocalDateTime;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/reserve")
public class ReservationServlet extends HttpServlet {
     private ReservationDAO reservationDAO;
    private BookDAO bookDAO;
    
    @Override
    public void init() {
        reservationDAO = new ReservationDAO();
        bookDAO = new BookDAO();
    }
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        Reservation reservation = new Reservation();
        reservation.setStudentName(request.getParameter("studentName"));
        reservation.setStudentId(request.getParameter("studentId"));
        int bookId = Integer.parseInt(request.getParameter("bookId"));
        reservation.setBookId(bookId);
        
        
        reservation.setReservationDate(LocalDateTime.now());
        
        boolean reservationSuccess = reservationDAO.reserveBook(reservation);
        boolean statusUpdateSuccess = bookDAO.updateBookStatus(bookId, "Reserved");
        
        if (reservationSuccess && statusUpdateSuccess) {
            response.sendRedirect("success.jsp");
        } else {
            request.setAttribute("error", "Reservation failed. Please try again.");
            RequestDispatcher dispatcher = request.getRequestDispatcher("reserveForm.jsp");
            dispatcher.forward(request, response);
        }
    }
}